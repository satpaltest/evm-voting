import logo from './logo.svg';
import bjp from './bjp.jpg'
import aap from './aap.jpg'
import cong from './congress.png'
import './App.css';
import React,{useState,useEffect} from 'react';


function App() {
  const [bjpCounter,SetBjpCounter]=useState(0);
  const [aapCounter,SetAapCounter]=useState(0);
  const [congressCounter,SetCongressCounter]=useState(0);
  const [reamingVote,setReamingVote]=useState(10)
  const TotalVote =10;
  useEffect(()=>{
    let submitedvote = bjpCounter+aapCounter+congressCounter;
    setReamingVote(TotalVote-submitedvote)
  },[bjpCounter,aapCounter,congressCounter])

  const pressBtn=(party)=>{
    let submitedvote = bjpCounter+aapCounter+congressCounter;
    if(submitedvote == TotalVote){
      alert('Voteing Complete');
      return false;
    }
    if(party=='bjp'){
    SetBjpCounter(bjpCounter+1)
    }
    if(party=='aap'){
      SetAapCounter(aapCounter+1)
    }
    if(party=='congress'){
      SetCongressCounter(congressCounter+1)
    }
  }
  return (
    <div className="App">
      <div className='total-vote'><p>Total Vote{TotalVote}</p>
      <p>Reaming Vote{reamingVote}</p>
      </div>
     <div className="bjp party-conatiner">
      <img src={bjp}/>
      <button onClick={()=>pressBtn('bjp')}>BJP</button>
      <div className="counter">{bjpCounter}</div>
     </div>
     <div className="app party-conatiner">
      <img src={aap}/>
      <button onClick={()=>pressBtn('aap')}>AAP</button>
      <div className="counter">{aapCounter}</div>
     </div>
     <div className="congress party-conatiner">
      <img src={cong}/>
      <button onClick={()=>pressBtn('congress')}>CONGRESS</button>
      <div className="counter">{congressCounter}</div>
     </div>
    </div>
  );
}

export default App;
